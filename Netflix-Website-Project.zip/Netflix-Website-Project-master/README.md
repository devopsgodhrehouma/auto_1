# Netflix-Website-Project
this is a html css website project
This is a website which i fuckin created for fun and for faking the madafucking Netflix Website
Fuck the shoits
HellYeah  !!
